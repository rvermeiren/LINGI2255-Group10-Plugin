# CSS folder
This folder contains the CSS files of the extension.

## Content

* **bootstrap_popover.css**: the stylesheet that is applied to the *popovers*,
the "popups" where information are displayed. It is bootstrap but it is only
applied to the elements with a *popoverWeCitizens* ID.
* **bootstrap.min.css**: Bootstrap is applied to the extension popup.
* **style.css**: custom stylesheet for the extension popup.
