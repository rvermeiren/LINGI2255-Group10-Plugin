# Views folder
This folder contains the HTML file of the extension.

## Content

* **popup.html**: the HTML template for the extension poup, in the top-right
corner of the browser.
