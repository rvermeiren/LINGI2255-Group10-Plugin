# Lib folder
This folder contains the JS libraries that are used in the extension.

## Content

* **bootstrap.min.js**: used to let the popovers pop
* **jquery-1.9.1.min.js**: jQuery library
* **pdf.js**: used to retrieve content of PDF files
* **pdf.worker.js**: PDF.JS auxiliary file
* **compatibility.js**: PDF.JS auxiliary file
