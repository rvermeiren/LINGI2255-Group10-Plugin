﻿KangoAPI.onReady(function() {

    $(document).ready(function () {
        $('#highlight-button').click(launchProcess);
    });

    function launchProcess() {
        //hightlightNames();
        $('#content-main').append('<span id="politicians"></div>');
        alert("FU");
        return ;
    }
});